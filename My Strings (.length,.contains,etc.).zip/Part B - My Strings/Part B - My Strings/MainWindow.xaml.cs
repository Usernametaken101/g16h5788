﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ThinkLib;

namespace Part_B___My_Strings
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int length(string s)                                // Length of a string
        {
            int i = 0;
            foreach (char x in s)
            {
                i++;
            }
            return i;
        }
        bool contains(string s, string subs)
        {
            bool v = false;
            if (indexOf(s , subs) != -1)
            {
                v = true;
            }
            return v;
        }
        int indexOf(string s, string subs)
        {
            int u = -1;
            //int y = -1;
            //int i = 0;
            for (int x = 0; x < length(s); x++)
            {
                if ( s[x] == subs[0] && s[x + length(subs) -1] == subs[length(subs) - 1])
                {
                    u = x;
                }
                //if (s[x] == subs[i])
                //{
                    
                //    if (x == subs[length(subs) - 1] && i == length(subs))
                //    {
                //        y = u;
                //    }
                //    i++;
                //}
                
            }
            return u;
        }
        string insertSubString (string s, string x, int pos)
        {
            string i = "";
            for(int p = 0; p < length(s); p++)
            {
                if (p == pos)
                {
                    i = i + x;
                }
                i = i + s[p];
            }
            return i;
        }
        string replaceSubString (string s, string ne, string old)
        {
            string i = "";
            for (int p = 0; p < length(s); p++)
            {
                if (s[p] == old[0])
                {
                    i = i + ne;
                    continue;
                }
                i = i + s[p];
            }
            return i;
        }
        string deleteSubString (string s, string subs)
        {
            string i = "";
            for (int p = 0; p < length(s); p++)
            {
                if (s[p] == subs[0] && s[p + length(subs) - 1] == subs[length(subs) - 1])
                {
                    continue;
                }
                i = i + s[p];
            }
            return i;
        }


        private void button_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(length("blob"), 4);

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(insertSubString("xxxx", "y", 2), "xxyxx");
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(replaceSubString("xxyxx","ooo", "y" ), "xxoooxx");
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(indexOf("xxyxx", "y"), 2);
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(deleteSubString("xxyxx", "y"), "xxxx");
        }

        private void button5_Click(object sender, RoutedEventArgs e)
        {
            Tester.TestEq(contains("xxyxx", "y"), true);
        }
    }
}
